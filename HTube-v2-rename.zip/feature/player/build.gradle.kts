plugins {
    alias(libs.plugins.htube.android.feature)
}

dependencies {
    implementation(projects.core.media)
    implementation(projects.core.playerui)
}
